import { Component } from '@angular/core';
import { SellerServiceService } from './seller-service.service';
import { Item } from './item';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'App5';
  name: String;
  itemdata : Item[];

constructor(private sellerservice: SellerServiceService) {
  console.log("constructor invoked");
}
searchItem(){
  console.log("invoked searchItem()");
  this.sellerservice.getItemByName("achaire").subscribe(itemdata=>this.itemdata = itemdata);
  console.log("my name is khan")
}
}