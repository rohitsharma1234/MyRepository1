import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Cart, ViewCart } from 'cart';


@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  private baseUrl='http://localhost:8081/searchItem';
  constructor(private http: HttpClient) { }
  getItemByName(name: String):Observable<any>{
  return this.http.get(`${this.baseUrl}/${name}`);
  }
  addToCart(cart: Cart): Observable<any> {
    return this.http.post(`http://localhost:4202/8/addToCart`,cart);
  }
  updateCart(cartView:ViewCart): Observable<any>{
 return this.http.post(`http://localhost:8082/cart/updateCart`,Cart);
  }
  viewCart(): Observable<any>{
    return this.http.get(`http://localhost:8081/1/getAllCartItems`);
  }
  deleteCart(): Observable<any>{
    return this.http.delete(`http://localhost:8081/{cartItemId}/deleteCartItemById`)
  }
}
