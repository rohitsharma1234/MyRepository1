import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../item';
import { SellerServiceService } from '../seller-service.service';
import { Cart } from 'cart';
@Component({
  selector: 'app-item-detail',
  templateUrl: './item-detail.component.html',
  styleUrls: ['./item-detail.component.css']
})
export class ItemDetailComponent implements OnInit {
  @Input() itemdata: Item
  cart:Cart[];
  abc:any;
  
  constructor(private pService:SellerServiceService) { }

  ngOnInit(): void {
  }
onSave(itemId: number){
 let  cart:Cart=new Cart(); 
 cart.itemId=itemId;
cart.quantity=1;
  this.pService.addToCart(cart).subscribe(abc=>{this.abc=abc;},
    error=>console.log("error")
  ) ;  
}

}